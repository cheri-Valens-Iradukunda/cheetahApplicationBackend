package com.cheetah.controller.report;

import com.cheetah.dto.Dto_imports;
import com.cheetah.dto.Dto_daily_report;
import com.cheetah.dto.Dto_totals;
import com.cheetah.models.Mdl_stockActions;
import com.cheetah.repository.Repo_expenses;
import com.cheetah.repository.Repo_product_price;
import com.cheetah.repository.Repo_stock_actions;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/report")
public class DailyReport {
    
    @Autowired
    public Repo_expenses expensesRepo;
    
    @Autowired
    public Repo_stock_actions stockActionsRepo;
    
    @Autowired
    public Repo_product_price productPriceRepo;
    
    @Autowired
    public Repo_expenses expensesRepository;
    
    @Autowired
    public DailyReportService dailyReportService;
    
    
    @GetMapping("/dailyReport/{date}/{number}")
    public List<Dto_daily_report> dailyReport(@PathVariable("date") String date,@PathVariable("number") int number){
        
        String from = date + " 00:00:00";
        String to = date+ " 23:59:59";
        System.out.println("---------- DAILY DATE IS "+ from + " -- " + to + " ----------");
        System.out.println("-------------------------------------------------");
        
        return getToDayReport(from, to, number);
        
    }
    
    @GetMapping("/monthly/{from}/{to}/{number}")
    public List<Dto_daily_report> getMonthlyReport(
            @PathVariable("from") String from,@PathVariable("to") String to,@PathVariable("number") int number
    ){
        String[] dates = to.split("-");
        int year = Integer.parseInt(dates[0]);
        int month = Integer.parseInt(dates[1]);
        
        LocalDate dateLen = LocalDate.of(year, month, 1);
        int dateLength = dateLen.lengthOfMonth();
        
        String from2 = from + "-01 00:00:00";
        String to2 = to+"-"+dateLength + " 23:59:59";
        
        return getMonthlyReportByDate(from2, to2,number);
        
    }
    
     @GetMapping("/monthlyTotals/{from}/{to}")
    public Dto_totals getMonthlyReportTotals(
            @PathVariable("from") String from,@PathVariable("to") String to
    ){
        //finding to
        String[] dates = to.split("-");
        int year = Integer.parseInt(dates[0]);
        int month = Integer.parseInt(dates[1]);
        
        LocalDate dateLen = LocalDate.of(year, month, 1);
        int dateLength = dateLen.lengthOfMonth();
        
        String from2 = from + "-01 00:00:00";
        String to2 = to+"-"+dateLength + " 23:59:59";
        
        return getMonthlyReportByDateSum(from2, to2);
        
    }
    
    @GetMapping("/dailyTotals/{from}")
    public Dto_totals getDailyReportTotals(
            @PathVariable("from") String from
    ){
        String from2 = from + " 00:00:00";
        String to2 = from + " 23:59:59";
        
        
        System.out.println("---------- DAILY DATE FOR TOTALS IS "+ from2 + " -- " + to2 + " ----------");
        System.out.println("-------------------------------------------------");
        
        return getMonthlyReportByDateSum(from2, to2);
        
    }
    
    public List<Dto_daily_report> getToDayReport(String from,String to, int number){
        
        List<Dto_daily_report> returnedResults = new ArrayList<>();
        try {
            PageRequest pageRequest = PageRequest.of(number, 20);
            List<Dto_imports> stockAction = stockActionsRepo.getSalesAndPurchaseLimit(from,to,pageRequest); 
            
            for(Dto_imports singleAction: stockAction){
                int amountUsed = 0;
                int quantityPurchase = (int) singleAction.getTotalPurchase();
                int quantitySold = (int) singleAction.getTotalSales();
                int amountPurchased = (int) singleAction.getAmountPurchased();
                int amountSold = (int) singleAction.getAmountSold();
                int openingAmount = 0;
                
                if(quantitySold > quantityPurchase){
                     openingAmount = dailyReportService.findOPeningStockValue(
                             singleAction.getPrice_id(), from,to, quantitySold, quantityPurchase
                     );
                }else{
                    
                }
                
                int totalProductProfit;
                int closingAmount = 0;
                if(amountSold == 0){
                    totalProductProfit = 0;
                }else{
                    int closingStock = stockActionsRepo.getLastQuantityRemain(singleAction.getPrice_id(), from, to);
                    
                    closingAmount = dailyReportService.findClosingStockValue(
                             singleAction.getPrice_id(),from, to,closingStock
                     );
                    int totalPurchase = amountPurchased + openingAmount;
                    int totalSells = amountSold + closingAmount;
                    totalProductProfit = (amountSold + closingAmount) - (amountPurchased + openingAmount);
                    
                }
                Mdl_stockActions openingStock = stockActionsRepo.FirstOpeningStock(
                    singleAction.getPrice_id(), from,to, 0);
                
                Dto_daily_report singleReport = new Dto_daily_report();
                singleReport.setAmount_purchased(amountPurchased);
                singleReport.setAmount_sold(amountSold);
                singleReport.setCategory_name(singleAction.getCetegory_name());
                singleReport.setProduct_name(singleAction.getProduct_name());
                singleReport.setType_name(singleAction.getType_name());
                singleReport.setQuantity_purchased(quantityPurchase);
                singleReport.setQuantity_sold(quantitySold);
                singleReport.setAmount_sold(amountSold);
                singleReport.setTotalProfit(totalProductProfit);
                singleReport.setOpening_stock(openingStock.getQuantity_in());
                
                returnedResults.add(singleReport);
                
                        
            }
            
            return returnedResults;
            
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
    
    
    public List<Dto_daily_report> getMonthlyReportByDate(String from,String to,int number){
        
        List<Dto_daily_report> returnedResults = new ArrayList<>();
        try {
            PageRequest pageRequest = PageRequest.of(number, 20);
            List<Dto_imports> stockAction = stockActionsRepo.getSalesAndPurchaseLimit(from,to,pageRequest); 
            
            for(Dto_imports singleAction: stockAction){
                
                int quantityPurchase = (int) singleAction.getTotalPurchase();
                int quantitySold = (int) singleAction.getTotalSales();
                int amountPurchased = (int) singleAction.getAmountPurchased();
                int amountSold = (int) singleAction.getAmountSold();
                int openingAmount = 0;
                
                if(quantitySold > quantityPurchase){
                     openingAmount = dailyReportService.findOPeningStockValue(
                             singleAction.getPrice_id(), from,to, quantitySold, quantityPurchase
                     );
                }else{
                    
                }
                
                int totalProductProfit;
                int closingAmount = 0;
                if(amountSold == 0){
                    totalProductProfit = 0;
                }else{
                    int closingStock = stockActionsRepo.getLastQuantityRemain(singleAction.getPrice_id(), from, to);
                    
                    closingAmount = dailyReportService.findClosingStockValue(
                             singleAction.getPrice_id(),from, to,closingStock
                     );
                    
                    int expenses;
                    if(expensesRepository.getExpensesAmountPerDate(from, to) == null){
                        expenses = 0;
                    }else{
                        expenses = expensesRepository.getExpensesAmountPerDate(from, to);
                    }
                    totalProductProfit = (amountSold + closingAmount) - (amountPurchased + openingAmount);
                    
                }
                Mdl_stockActions openingStock = stockActionsRepo.LastClosingStock(
                    singleAction.getPrice_id(), from,to, 0);
                
                
                
                Dto_daily_report singleReport = new Dto_daily_report();
                singleReport.setAmount_purchased(amountPurchased);
                singleReport.setAmount_sold(amountSold);
                singleReport.setCategory_name(singleAction.getCetegory_name());
                singleReport.setProduct_name(singleAction.getProduct_name());
                singleReport.setType_name(singleAction.getType_name());
                singleReport.setQuantity_purchased(quantityPurchase);
                singleReport.setQuantity_sold(quantitySold);
                singleReport.setTotalProfit(totalProductProfit);
                singleReport.setOpening_stock(openingStock.getQuantity_remain());
                
                returnedResults.add(singleReport);
                        
            }
            
            return returnedResults;
            
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
    
    public Dto_totals getMonthlyReportByDateSum(String from,String to){
        
        System.out.println("---------- GET INDEEP OF FINDING TOTALS ----------");
        System.out.println("-------------------------------------------------");
        try {
            List<Dto_imports> stockAction = stockActionsRepo.getSalesAndPurchase(from,to); 
            
            if(stockAction == null){
            
                System.out.println("---------- THERE IS NO ACTIONS TO DAY ----------");
                System.out.println("-------------------------------------------------");
                
            }
            
            int totalProfitIn = 0;
            int totalPurchasesIn = 0;
            int totalSalesIn = 0;
            int totalOpeningStockIn = 0;
            int totalClosingStockIn = 0;
            int totalExp = 0;
            for(Dto_imports singleAction: stockAction){
                
                System.out.println("----------WORKING ON " + singleAction.getProduct_name()
                        + " " + singleAction.getType_name() + " " + singleAction.getCetegory_name()+ "  ----------");
                System.out.println("-------------------------------------------------");
                
                int quantityPurchase = (int) singleAction.getTotalPurchase();
                int quantitySold = (int) singleAction.getTotalSales();
                int amountPurchased = (int) singleAction.getAmountPurchased();
                int amountSold = (int) singleAction.getAmountSold();
                int openingAmount = 0;
                
                
                System.out.println("---------- DETAILS ABOUT IT: QUANTITY PURCHASED: "+ quantityPurchase + " QUANTITY SOLD: " + quantitySold + " ----------");
                System.out.println("-------------------------------------------------");
                
//                if(quantitySold > quantityPurchase){
                    
                    System.out.println("---------- QUANTITY SOLD IS GREATER THAN QUANTITY PURCHASE ----------");
                    System.out.println("-------------------------------------------------");
                    
                     openingAmount = dailyReportService.findOPeningStockValue(
                             singleAction.getPrice_id(), from,to, quantitySold, quantityPurchase
                     );
                     
                    System.out.println("---------- OPENING AMOUNT IS " + openingAmount+ " ----------");
                    System.out.println("-------------------------------------------------");
                    
//                }else{
//                    
//                }
                
                int totalProductProfit;
                int closingAmount = 0;
                if(amountSold == 0){
                    totalProductProfit = 0;
                }
                else{
                    int closingStock = stockActionsRepo.getLastQuantityRemain(singleAction.getPrice_id(), from, to);
                    
                    closingAmount = dailyReportService.findClosingStockValue(
                             singleAction.getPrice_id(),from, to,closingStock
                     );
                    
                    int expenses;
                    if(expensesRepository.getExpensesAmountPerDate(from, to) == null){
                        expenses = 0;
                    }else{
                        expenses = expensesRepository.getExpensesAmountPerDate(from, to);
                    }
                    totalExp = expenses; 
                    totalProductProfit = (amountSold + closingAmount) - (amountPurchased + openingAmount);
                    
                    
                    System.out.println("---------- AMOUNT SOLD: "+amountSold +" CLOSING AMOUNT: "+ closingAmount
                            +" AMOUNT PURCHASED: " + amountPurchased + " OPENING AMOUNT: "+openingAmount+" ----------");
                    System.out.println("-------------------------------------------------");
                    
//                    totalProfitIn += totalProductProfit;
                    
                }
                Mdl_stockActions openingStock = stockActionsRepo.LastClosingStock(
                    singleAction.getPrice_id(), from,to, 0);
                
                
                totalProfitIn += totalProductProfit;
                totalPurchasesIn += amountPurchased;
                totalSalesIn += amountSold;
                totalOpeningStockIn += openingAmount;
                totalClosingStockIn +=closingAmount;
                
                
                        
            }
            Dto_totals totals = new Dto_totals();
            
            totals.setClosingAmount(totalClosingStockIn);
            totals.setOpeningAmount(totalOpeningStockIn);
            totals.setTotalExpenses(totalExp);
            totals.setTotalPurchases(totalPurchasesIn);
            totals.setTotalSells(totalSalesIn);
            totals.setTotal(totalProfitIn);
            
            return totals;
            
        } catch (Exception e) {
            return new Dto_totals();
        }
    }
    
}
