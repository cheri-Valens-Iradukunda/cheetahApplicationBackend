package com.cheetah.controller.report;

import com.cheetah.models.Mdl_stockActions;
import com.cheetah.repository.Repo_expenses;
import com.cheetah.repository.Repo_product_price;
import com.cheetah.repository.Repo_stock_actions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DailyReportService {
    @Autowired
    public Repo_expenses expensesRepo;
    
    @Autowired
    public Repo_stock_actions stockActionsRepo;
    
    @Autowired
    public Repo_product_price productPriceRepo;
    

    //<editor-fold defaultstate="collapsed" desc="late ones">
    
//    public int findOPeningStockValue(long productId,String from,String to,int quantitySold,int quantityPurchase){
//        int openingAmount = 0;
//        int remainingQuantitySold  = quantitySold - quantityPurchase;
//        int limit = 0;
//        while(remainingQuantitySold >0){
//
//             System.out.println("---------START WHILE LOOP --------");
//
//            Mdl_stockActions openAction = stockActionsRepo.FirstOpeningStock1(
//                    productId, from, limit);
//
//            if(remainingQuantitySold > openAction.getQuantity_used()){
//
//                 System.out.println("---------SECOND CONDITION IS TRUE --------" + remainingQuantitySold);
//
//                System.out.println("---------LOOP " + openAction.getQuantity_used() + " --------");
//
//                remainingQuantitySold -= openAction.getQuantity_used();
//                openingAmount += openAction.getAmount_used();
//
//                System.out.println("---------LOOP REMAIN" + remainingQuantitySold + " --------");
//                limit++;
//                continue;
//            }
//            else{
//
//                 System.out.println("---------SECOND CONDTION IS FALSE --------");
//
//                System.out.println("---------LOOP " + openAction.getQuantity_used() + " --------");
//                int pricePerOne = openAction.getAmount_used()/openAction.getQuantity_used();
//                openingAmount += pricePerOne * remainingQuantitySold;
//
//                 System.out.println("---------END OF LOOP --------");
//
//                break;
//            }
//
//        }
//
//
//        System.out.println("---------AFTER LOOP " + openingAmount + " --------");
//        
//        return openingAmount;
//                    
//        
//    }
//    
//    public int findClosingStockValue(long productId,String from, String to,int closingStock){
//        int closingAmount = 0;
//        int remainingClosingStock  = closingStock;
//        System.out.println("------------------------------------REMAIN CLOSING STOCK " + remainingClosingStock + "-----" );
//        int limit = 0;
//        while(remainingClosingStock >0){
//
//             System.out.println("---------START WHILE LOOP --------");
//
//            Mdl_stockActions openAction = stockActionsRepo.LastClosingStock1(
//                    productId, to, limit);
//
//            if(remainingClosingStock > openAction.getQuantity_used()){
//
//                 System.out.println("---------SECOND CONDITION IS TRUE --------" + remainingClosingStock);
//
//                System.out.println("---------LOOP " + openAction.getQuantity_used() + " --------");
//
//                remainingClosingStock -= openAction.getQuantity_used();
//                closingAmount += openAction.getAmount_used();
//
//                System.out.println("---------LOOP REMAIN" + remainingClosingStock + " --------");
//                limit++;
//                continue;
//            }
//            else{
//
//                 System.out.println("---------SECOND CONDTION IS FALSE --------");
//
//                System.out.println("---------LOOP " + openAction.getQuantity_used() + " --------");
//                int pricePerOne = openAction.getAmount_used()/openAction.getQuantity_used();
//                closingAmount += pricePerOne * remainingClosingStock;
//
//                 System.out.println("---------END OF LOOP --------");
//
//                break;
//            }
//
//        }
//
//
//        System.out.println("---------AFTER LOOP " + closingAmount + " --------");
//        
//        return closingAmount;
//                    
//        
//    }
    //</editor-fold>
    
    public int findOPeningStockValue(long productId,String from,String to,int quantitySold,int quantityPurchase){
        System.out.println("----------------------------------------------------------");
        System.out.println("------------------START FINDING OPENING AMOUNT ----------------------");
                
        int openingAmount = 0;
        int remainingQuantitySold  = quantityPurchase - quantitySold;
        
        System.out.println("---------- THE REMAINING QUANTITY IS " + remainingQuantitySold+" ----------");
        System.out.println("-------------------------------------------------");

        int limit = 0;
        while(remainingQuantitySold >0){
            System.out.println("INSIDE LOOP");

            Mdl_stockActions openAction = stockActionsRepo.FirstOpeningStock1(
                    productId, from, limit);
            System.out.println("ramining stock is" + remainingQuantitySold + " " + openAction.getQuantity_used());
            if(remainingQuantitySold > openAction.getQuantity_used()){


                remainingQuantitySold -= openAction.getQuantity_used();
                openingAmount += openAction.getAmount_used();

                limit++;
                continue;
            }
            else{
                int pricePerOne = openAction.getAmount_used()/openAction.getQuantity_used();
                openingAmount += pricePerOne * remainingQuantitySold;

                break;
            }

        }

        
        System.out.println("---------- FINISHING OPENING AMOUNT IS " + openingAmount+ " ----------");
        System.out.println("-------------------------------------------------");

        return openingAmount;
                    
        
    }
    
    public int findClosingStockValue(long productId,String from, String to,int closingStock){
        int closingAmount = 0;
        int remainingClosingStock  = closingStock;
        int limit = 0;
        while(remainingClosingStock >0){

            Mdl_stockActions openAction = stockActionsRepo.LastClosingStock1(
                    productId, to, limit);

            if(remainingClosingStock > openAction.getQuantity_used()){

                remainingClosingStock -= openAction.getQuantity_used();
                closingAmount += openAction.getAmount_used();

                limit++;
                continue;
            }
            else{

                int pricePerOne = openAction.getAmount_used()/openAction.getQuantity_used();
                closingAmount += pricePerOne * remainingClosingStock;

                break;
            }

        }

        
        return closingAmount;
                    
        
    }
    
    
    
}
